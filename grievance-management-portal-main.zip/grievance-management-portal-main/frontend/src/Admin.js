import React from 'react';

function Admin() {
  return (
    <div>
      <h1>Hello Admin</h1>
    </div>
  );
}

export default Admin;
